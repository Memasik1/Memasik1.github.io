# Third-party visual assets

The expedition item textures include adapted copies from the following CC0
collections. They may be used, modified, and redistributed with this resource
pack without attribution requirements.

## Idylwild's Arsenal

- Author: Idylwild
- Source: https://opengameart.org/content/idylwilds-arsenal
- License: CC0 1.0
- Used for expedition weapons.

## Idylwild's Armory

- Author: Idylwild
- Source: https://opengameart.org/content/idylwilds-armory
- License: CC0 1.0
- Used for expedition armor and the field shield.

## 496 Pixel Art Icons for Medieval/Fantasy RPG

- Author: Henrique Lazarini (7Soul1)
- Source: https://opengameart.org/content/496-pixel-art-icons-for-medievalfantasy-rpg
- License: CC0 1.0
- Used for expedition mini-artifacts.
- Used for expedition materials (adapted rock, crystal and metal icons).

## Farmer's Delight

- Author: vectorwing
- Source: https://github.com/vectorwing/FarmersDelight
- License: MIT
- Used for cooking ingredients, prepared foods, dishes and cookware.
- A copy of the license is included in `licenses/FarmersDelight-MIT.txt`.
