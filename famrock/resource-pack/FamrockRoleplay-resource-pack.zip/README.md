# FamrockRoleplay resource pack

This directory is the portable source of the server resource pack.

- Put PNG files under `assets/famrock/textures/item/`.
- Put custom item model JSON files under `assets/famrock/models/item/`.
- Put vanilla `CustomModelData` overrides under `assets/minecraft/models/item/`.
- Keep `pack.mcmeta` at the root of this directory.

Registered textures are described in `custom-models.json`. The build script
generates both custom model files and grouped vanilla overrides automatically.

Build the distributable ZIP from the repository root:

```powershell
.\scripts\build-resource-pack.ps1
```

The ZIP and its SHA-1 file are written to `release/resource-pack/`.
The ZIP must be served through a direct public HTTPS URL.

Current public URL:

```text
https://raw.githubusercontent.com/Memasik1/Memasik1.github.io/master/famrock/resource-pack/FamrockRoleplay-resource-pack.zip
```

The hosted file lives in the public repository `Memasik1/Memasik1.github.io`
at `famrock/resource-pack/FamrockRoleplay-resource-pack.zip`. After rebuilding
the pack, replace that file and copy the new value from
`FamrockRoleplay-resource-pack.zip.sha1` into `resource-pack.yml`.

The authoritative item IDs and suggested paths are documented in
`docs/resource-pack-custom-model-data.md`.
