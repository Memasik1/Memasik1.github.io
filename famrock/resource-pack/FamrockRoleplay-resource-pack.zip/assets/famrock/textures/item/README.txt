Place transparent PNG item textures in this directory.
Keep category subdirectories aligned with docs/resource-pack-custom-model-data.md.
