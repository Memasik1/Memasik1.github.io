Place generated or handheld custom item model JSON files in this directory.
Model paths must match the overrides in assets/minecraft/models/item.
