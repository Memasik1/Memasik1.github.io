Place vanilla item model overrides here.
When several custom items share one Material, keep all predicates in one file
and sort custom_model_data values in ascending order.
